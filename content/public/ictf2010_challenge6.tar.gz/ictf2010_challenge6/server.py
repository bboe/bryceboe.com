#!/usr/bin/env python
import cgi, logging, logging.handlers, os, random, re, socket, sqlite3, sys
import threading, time, urlparse, Cookie, SocketServer
from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler

TEMPLATE = """<!DOCTYPE HTML>
<html>
<head><title>User Administration</title></head>
<body>

%s

<video width="320" height="240" controls="controls" autoplay="autoplay">
  <source src="http://www.archive.org/download/MannyCanard_USCSpeedRemix/MannyCanardH264.ogv" type="video/ogg" />
  <source src="http://www.archive.org/download/MannyCanard_USCSpeedRemix/MannyCanardH264_512kb.mp4" type="video/mp4" />
Your browser does not support the video tag.
</video>

%s

</body>
</html>"""

UPLOAD = """
<form action="/" method="post" enctype="multipart/form-data">
<input type="hidden" name="csrf" value="%s" />
<input type="file" name="control" />
<input type="submit" value="Upload control file" />
</form>"""

USER_RE = re.compile('^[a-z]{1,6}$')
PSWD_RE = re.compile('^[0-9]{1,2}$')
CMD_RE = re.compile('^[ -~]+$')

OUTPUT_DELAY = 3
MAX_FILE_SIZE = 40

DATABASE = 'database.sql'
SECRET = "The secret is: http://hackiswack.com/videos/viewvideo/23/hack-is-wack/blocka-blocka"
ALMOST_SECRET = 'Good job! You are almost to the <em>secret</em>.'
ALMOST_SECRET2 = 'This info is not special either.'
NOT_SECRET = 'There is nothing special with regular users\' info.'

USERS = [('admin',  '99', ALMOST_SECRET, True, False),
         ('dev',    '99', ALMOST_SECRET, True, False),
         ('devel',  '99', ALMOST_SECRET, True, False),
         ('root',   '99', ALMOST_SECRET, True, False),
         ('zzyzx',  '83', ALMOST_SECRET2, True, True),
         ('secret', '66', SECRET, False, False),
         ('a',      '50', 'The first letter of the alphabet.', False, True),
         ('bush',   '50', 'Good thing you watched the video.', False, True),
         ('canard', '50', 'Who is this person?', False, True),
         ('george', '50', 'See bush.', False, True),
         ('ictf',   '50', 'See ictf10.', False, True),
         ('ictf10', '50', ''.join(['You are playing it. <a href="http://twitt',
                                   'er.com/search?q=%23iCTF10">#iCTF10</a>']),
          False, True),
         ('manny',  '50', 'See canard.', False, True),
         ('stop',   '50', 'God that video was annoying.', False, True),
         ('stopit', '50', 'Really annoying.', False, True),
         ('test',   '50', NOT_SECRET, False, True),
         ('ucsb',   '50', 'University of Casual Sex and Beer!', False, True),
         ('user',   '50', NOT_SECRET, False, True),
         ('vigna',  '50', 'His real password is not 50.', False, True)]

S = {
    'admin_login':'<p>Successful administrator login for user `%s`</p>\n',

    'add' :'Add a user to table `users`. Arguments: username password',
    'help':'Display help.',
    'info':'Get `info` field if the user is_enabled. Arguments: username',
    'list':''.join(['List users, their status (admin, regular) and their info',
                    'from table `users` where `is_enabled` is true.']),
    'admin'   :'User `%s` is not an administrator. Cannot send command.',
    'csrf'    :'Invalid CSRF token. Try again.',
    'large'   :'The control file must be %d bytes or less.' % MAX_FILE_SIZE,
    'form'    :'Invalid form submission.',
    'inactive':'User `%s` is not active.',
    'lines'   :'The control file must have exactly 3 lines.',
    'mismatch':'Invalid password for `%s`.',
    'nonexist':'User `%s` does not exist.',
    'password':'The password must match `%s`.' % PSWD_RE.pattern,
    'username':'username `%%s` does not match `%s`.' % USER_RE.pattern,
    'cmd_re':'command `%%s` does not match `%s`.' % CMD_RE.pattern,

    'args':'<p>Invalid arguments for: `%s`</p>',
    'cmd' :'<p>Invalid command: `%s` (try `help`)</p>',

    'in_inactive':'<h1>Invalid or nonactive user: %s</h1>\n',

    'cookie_invalid':'Invalid cookie in header. No use messing around here.',
    'cookie_msg'    :'Only cookie `msg` allowed. No use messing around here.'
}

CMDS = {'add':2, 'help':0, 'info':1, 'list':0}


def sanitize_output(output):
    new = ''
    for c in output:
        if c == '\\':
            new += r'\\'
        elif c == '\n':
            new += r'\n'
        elif c == '\t':
            new += r'\t'
        elif 31 < ord(c) < 127:
            new += c
        else:
            new += r'\%02x' % ord(c)
    return new

class StreamFilter(logging.Filter):
    def filter(self, record):
        if record.exc_info:
            etype, evalue, etb = record.exc_info
            record.exc_text = 'Line %d: %s %s' % (etb.tb_lineno, etype, evalue)
        return True

class ThreadedHTTPServer(SocketServer.ThreadingMixIn, HTTPServer):
    TABLE_SQL = ''.join(['create table users (user text, pass text, info text',
                         ', is_admin integer, is_enabled integer)'])
    INDEX_SQL = 'create unique index user_idx on users(user)'

    csrf_expire = 30
    request_queue_size = 128

    @staticmethod
    def create_database():
        conn = sqlite3.connect(DATABASE)
        conn.execute(ThreadedHTTPServer.TABLE_SQL)
        conn.execute(ThreadedHTTPServer.INDEX_SQL)
        for user in USERS:
            conn.execute('insert into users values(?, ?, ?, ?, ?)', user)
        conn.commit()
        conn.close()
    
    def __init__(self, *args, **kwargs):
        HTTPServer.__init__(self, *args, **kwargs)
        self.csrf_keys = {}
        self.csrf_by_time = []
        self.csrf_lock = threading.Lock()
        self.counter = 0
        self.instance_counter = 0
        self.start = time.time()
        self.timestamp = self.start
        self.counter_lock = threading.Lock()

        if not os.path.isfile(DATABASE):
            self.create_database()
        os.chmod(DATABASE, 0444)

    def record_request(self):
        self.counter_lock.acquire()
        self.instance_counter += 1
        self.counter += 1
        timestamp = time.time()
        diff = timestamp - self.timestamp
        if diff > OUTPUT_DELAY:
            sys.stdout.write(' Total Requests: %7d RPS: %7.2f AVG: %7.2f\r' %
                             (self.counter, self.instance_counter / diff,
                              self.counter / (timestamp - self.start)))
            sys.stdout.flush()
            self.instance_counter = 0
            self.timestamp = timestamp
        self.counter_lock.release()
        return timestamp        

    def create_csrf(self):
        self.csrf_lock.acquire()
        while True:
            csrf = '%d' % random.randint(0, 0xFFFFFFFF)
            if csrf not in self.csrf_keys:
                self.csrf_keys[csrf] = True
                self.csrf_by_time.append((self.timestamp + self.csrf_expire,
                                          csrf))
                self.csrf_lock.release()
                return csrf

    def check_csrf(self, csrf):
        self.csrf_lock.acquire()
        cur = self.timestamp
        while self.csrf_by_time and self.csrf_by_time[0][0] <= cur:
            ttime, tmp = self.csrf_by_time.pop(0)
            del self.csrf_keys[tmp]
        if csrf in self.csrf_keys and self.csrf_keys[csrf]:
            retval = True
            self.csrf_keys[csrf] = False
        else:
            retval = False
        self.csrf_lock.release()
        return retval

class Handler(BaseHTTPRequestHandler):
    eh = logging.FileHandler('exceptions.log', delay=True)
    eh.setLevel(logging.ERROR)
    rh = logging.handlers.TimedRotatingFileHandler('requests.log', 'H', 1)
    rh.setLevel(logging.INFO)
    sh = logging.StreamHandler()
    sh.addFilter(StreamFilter())
    sh.setLevel(logging.WARN)

    elogger = logging.getLogger('exceptions')
    elogger.addHandler(eh)
    elogger.addHandler(sh)
    elogger.setLevel(logging.ERROR)

    logger = logging.getLogger('http_server')
    logger.addHandler(rh)
    logger.addHandler(sh)
    logger.setLevel(logging.INFO)

    def log_request(self, code='-', size='-'):
        if hasattr(self, 'message_logged'): return

        if hasattr(self, 'user_input'):
            ui = '"%s"' % self.user_input
        else:
            ui = '-'
        if hasattr(self, 'response_msg'):
            rm = '"%s"' % self.response_msg
        else:
            rm = '-'

        kwargs = {'extra':'%s %s' % (ui, rm)}
        self.log_message('"%s" %s', self.requestline, str(code), **kwargs)
        self.message_logged = True

    def log_error(self, *args): pass

    def log_message(self, format, *args, **kwargs):
        log = '%s:%d [%s] %s %s %s'
        ip, port = self.client_address

        if hasattr(self, 'User-Agent') and 'User-Agent' in self.headers:
            user_agent = '"%s"' % self.headers['User-Agent']
        else:
            user_agent = '-'

        Handler.logger.info(log % (ip, port,
                                   self.log_date_time_string(self.timestamp),
                                   format % args, user_agent, kwargs['extra']))

    def handle_one_request(self):
        self.timestamp = self.server.record_request()
        try:
            BaseHTTPRequestHandler.handle_one_request(self)
        except socket.error: pass
        except:
            Handler.elogger.exception('')

    def log_date_time_string(self, timestamp):
        if not timestamp:
            timestamp = time.time()
        year, month, day, hh, mm, ss, x, y, z = time.localtime(timestamp)
        s = "%02d/%3s/%04d %02d:%02d:%02d" % (day, self.monthname[month],
                                              year, hh, mm, ss)
        return s

    def help(self, conn):
        data = '<h1>Commands</h1>\n<dl>\n'
        for cmd in sorted(CMDS):
            data += '  <dt>%s</dt>\n' % cmd
            data += '    <dd>%s</dd>\n' % S[cmd]
        data += '</dl>'
        return data

    def list(self, conn):
        query = 'select user, info, is_admin from users where is_enabled=1'
        data = '<h1>Active User List</h1>\n<dl>\n'
        for user, info, is_admin in conn.execute(query):
            if is_admin:
                status = '[admin]'
            else:
                status = '[regular]'
            data += '  <dt>%s %s</dt>\n  <dd>%s</dd>\n' % (status, user, info)
        data += '</dl>\n'
        res = conn.execute('select count(user) from users where is_enabled=0')
        data += '<p>There are %d deactivated users.</p>\n' % res.fetchone()
        return data

    def add(self, conn, user, pswd):
        conn.execute('insert into users values(?, ?, ?, ?, ?)',
                     (user, pswd, 'Oops this shouldn\'t happen.', 0, 0))
        data = '<h1>Disabled User Added *Notify Competition Admin*</h1>\n'
        data += ''.join(['<p>The database should be read only. Please notify'
                         ' the competition admins and look elsewhere to solve'
                         ' this challenge.</p>\n'])
        return data

    def info(self, conn, user):
        query = ''.join(['select user, info from users ',
                         'where is_enabled=1 and user=\'%s\''])
        c = conn.execute(query % user)
        result = c.fetchone()
        if result:
            try:
                data = '<h1>Info for: %s</h1>\n<p>%s</p>\n' % result
            except TypeError:
                data = '<h1>Format Error -- Output Results</h1>\n<ul>\n'
                for i in result:
                    data += '  <li>%s</li>\n' % i
                data += '</ul>\n'
        else:
            data = S['in_inactive'] % user
        return data

    def send_redirect(self, msg):
        self.response_msg = msg
        self.send_response(302)
        self.send_header('Location', '/')
        cookies = Cookie.SimpleCookie()
        cookies['msg'] = msg
        cookies['msg']['Max-Age'] = 1
        self.send_header('Set-Cookie', cookies.output(header=''))
        self.end_headers()

    def process_command(self, conn, user, cmd, *args):
        if cmd in CMDS:
            if len(args) == CMDS[cmd]:
                try:
                    data = getattr(self, cmd)(conn, *args)
                except (sqlite3.OperationalError, sqlite3.IntegrityError,
                        sqlite3.Warning), e:
                    data = '<h3>sqlite3 error</h3>\n'
                    data += '<p>Error: %s</p>\n' % str(e)
                except:
                    Handler.elogger.exception('')                    
                    data = '<h3>Unexpected Error</h3>\n'
                    data += '<p>Error: %s</p>\n' % str(e)
                    data += '<p>Exception logged and may be fixed.</p>\n'
            else:
                data = S['args'] % cmd
        else:
            data = S['cmd'] % cmd

        self.send_response(200)
        self.end_headers()
        self.wfile.write(TEMPLATE % (S['admin_login'] % user, data))

    def do_GET(self):
        url = urlparse.urlparse(self.path)
        if self.path != '/':
            self.send_error(404)
            return

        if 'cookie' in self.headers:
            format = '<p style="color:red">%s</p>\n'
            try:
                cookies = Cookie.SimpleCookie(self.headers['cookie'])
                if 'msg' not in cookies or len(cookies) > 1:
                    msg = format % S['cookie_msg']
                else:
                    msg = format % cookies['msg'].value
            except Cookie.CookieError:
                msg = format % S['cookie_invalid']
        else:
            msg = ''
        self.send_response(200)
        self.end_headers()
        self.wfile.write(TEMPLATE % (msg, UPLOAD % self.server.create_csrf()))

    def do_POST(self):
        if 'content-type' not in self.headers:
            return self.send_redirect(S['form'])
        form = cgi.FieldStorage(
            fp=self.rfile, headers=self.headers,
            environ={'REQUEST_METHOD':'POST',
                     'CONTENT_TYPE':self.headers['Content-Type']})
        if (len(form) != 2 or 'csrf' not in form or 'control' not in form
            or isinstance(form['csrf'], list)
            or isinstance(form['control'], list)
            or not form['control'].filename):
            return self.send_redirect(S['form'])
        if not self.server.check_csrf(form['csrf'].value):
            return self.send_redirect(S['csrf'])

        control = form['control']
        data = control.file.read(MAX_FILE_SIZE + 1)
        if len(data) > MAX_FILE_SIZE:
            return self.send_redirect(S['large'])
        lines = data.split('\n')
        if lines[-1] == '': lines.pop()
        if len(lines) != 3:
            return self.send_redirect(S['lines'])

        if data:
            self.user_input = sanitize_output(data)

        user = lines[0]
        pswd = lines[1]
        cmd = lines[2]

        if not USER_RE.match(user):
            return self.send_redirect(S['username'] % user)
        if not PSWD_RE.match(pswd):
            return self.send_redirect(S['password'])
        if not CMD_RE.match(cmd):
            return self.send_redirect(S['cmd_re'] % cmd)

        conn = sqlite3.connect(DATABASE)
        try:
            c = conn.execute('select * from users where user=?', (user,))
            result = c.fetchone()
            if not result:
                return self.send_redirect(S['nonexist'] % user)
            _, user_pswd, info, is_admin, is_active = result
            if pswd != user_pswd:
                return self.send_redirect(S['mismatch'] % user)
            if not is_active:
                return self.send_redirect(S['inactive'] % user)
            if not is_admin:
                self.send_redirect(S['admin'] % user)
            self.process_command(conn, user, *cmd.split(' '))
        finally:
            conn.close()


def main():
    try:
        port = int(sys.argv[1])
    except IndexError:
        port = 8000
    except ValueError:
        print 'Invalid port value: %s' % sys.argv[1]
        return 1
    server = ThreadedHTTPServer(('', port), Handler)
    print 'Server listening on port %d' % port

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print '\nGoodbye'

if __name__ == '__main__':
    sys.exit(main())
