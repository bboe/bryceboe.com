#!/usr/bin/env python
import Cookie, crawle, httplib, re, unittest
from server import S, MAX_FILE_SIZE, USERS, SECRET
from server import ALMOST_SECRET, NOT_SECRET, ALMOST_SECRET2

ADDR = 'localhost'
PORT = 8000

URL = 'http://%s:%d' % (ADDR, PORT)
VALUE_RE = re.compile('value="([^"]+)')

USR = 'user'
U_SECRET = 'secret'
ADMIN = 'admin'

def get_msg(rr):
    cookies = Cookie.SimpleCookie(rr.response_headers['set-cookie'])
    return cookies['msg'].value

class TestHandler(unittest.TestCase):
    def setUp(self):
        self.cc = crawle.HTTPConnectionControl(crawle.Handler(), timeout=5)
        self.csrf = self.getCSRF()

    def getCSRF(self):
        rr = crawle.RequestResponse(URL, redirects=None)
        self.cc.request(rr)
        self.assertEqual(200, rr.response_status)
        self.assertEqual(URL, rr.response_url)
        self.assertNotEqual(0, len(rr.response_body))
        return VALUE_RE.findall(rr.response_body)[0]

    def build_response(self, files=None, params=None):
        if params == None:
            params={'csrf':self.csrf}
        return crawle.RequestResponse(URL, method='POST', redirects=None,
                                      params=params, files=files)

    def testTooFewParams(self):
        rr = self.build_response()
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['form'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testTooManyParams(self):
        rr = self.build_response(params={'control':'', 'csrf':'', 'a':''})
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['form'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testDuplicateCSRF(self):
        rr = self.build_response([('csrf', '_', 'bad\n00\n'),
                                  ('control', '_', 'bad\n00\n')])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['form'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testDuplicateControl(self):
        rr = self.build_response([('control', '_', 'bad\n00\n'),
                                  ('control', '_', 'bad\n00\n')])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['form'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testInvalidCSRF(self):
        rr = self.build_response([('control', 'a', 'a')], {'csrf':'a'})
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['csrf'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testControlTooLarge(self):
        rr = self.build_response([('control', '_', 'A' * (MAX_FILE_SIZE + 1))])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['large'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testTooFewLines(self):
        rr = self.build_response([('control', '_', '%s\n50' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['lines'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testNonExistentUser(self):
        user = 'bad'
        rr = self.build_response([('control', '_', '%s\n00\n ' % user)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['nonexist'] % user, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testTooLongUsername(self):
        user = 'testaaa'
        rr = self.build_response([('control', '_', '%s\n00\n ' % user)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['username'] % user, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testNonLowerCaseUsername(self):
        user = 'A'
        rr = self.build_response([('control', '_', '%s\n50\n ' % user)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['username'] % user, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testTooLongPassword(self):
        rr = self.build_response([('control', '_', '%s\n000\n ' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['password'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testNonNumericPassword(self):
        rr = self.build_response([('control', '_', '%s\nA\n ' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['password'], get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testInvalidPassword(self):
        rr = self.build_response([('control', '_', '%s\n11\n ' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['mismatch'] % USR, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testInactiveAccount(self):
        rr = self.build_response([('control', '_', '%s\n66\n ' % U_SECRET)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['inactive'] % U_SECRET, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testInvalidCommandString(self):
        cmd = '\t'
        rr = self.build_response([('control', '_', '%s\n50\n%s' % (USR, cmd))])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['cmd_re'] % cmd, get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testNoCommandString(self):
        rr = self.build_response([('control', '_', '%s\n50\n\n' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['cmd_re'] % '', get_msg(rr))
        self.assertEqual(0, len(rr.response_body))

    def testNotAuthorizedandInvalidCommand(self):
        cmd = 'test'
        rr = self.build_response([('control', '_', '%s\n50\n%s' % (USR, cmd))])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertEqual(S['admin'] % USR, get_msg(rr))
        self.assertTrue(S['cmd'] % cmd in rr.response_body)

    def testInvalidCommandArguments(self):
        cmd = 'info'
        rr = self.build_response([('control', '_', '%s\n50\n%s' % (USR, cmd))])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertTrue(S['args'] % cmd in rr.response_body)

    def testValidCommandHelp(self):
        rr = self.build_response([('control', '_', '%s\n50\nhelp\n' % USR)])
        self.cc.request(rr)
        self.assertEqual(302, rr.response_status)
        self.assertTrue(S['list'] in rr.response_body)

    def testList(self):
        rr = self.build_response([('control', '_', '%s\n50\nlist' % USR)])
        self.cc.request(rr)
        for user, _, _, _, is_enabled in USERS:
            if not is_enabled: continue
            self.assertTrue(user in rr.response_body)

    def testInfo(self):
        control = '%s\n50\ninfo user' % USR
        rr = self.build_response([('control', '_', control)])
        self.cc.request(rr)
        self.assertTrue(NOT_SECRET in rr.response_body)

    def testInfoInactive(self):
        control = '%s\n50\ninfo %s' % (USR, U_SECRET)
        rr = self.build_response([('control', '_', control)])
        self.cc.request(rr)
        self.assertTrue(S['in_inactive'] % U_SECRET in rr.response_body)

    def testAdd(self):
        control = '%s\n50\nadd bob 00' % USR
        rr = self.build_response([('control', '_', control)])
        self.cc.request(rr)
        self.assertTrue('readonly database' in rr.response_body)

    def testRealAdmin(self):
        rr = self.build_response([('control', '_', 'zzyzx\n83\ninfo zzyzx')])
        self.cc.request(rr)
        self.assertEqual(200, rr.response_status)
        self.assertTrue(ALMOST_SECRET2 in rr.response_body)

    def testExploitAdmin(self):
        exploit = "%s\n50\ninfo 0'or`user`='%s" % (USR, ADMIN)
        rr = self.build_response([('control', '_', exploit)])
        self.cc.request(rr)
        self.assertTrue(ALMOST_SECRET in rr.response_body)

    def testExploitSecret(self):
        exploit = "%s\n50\ninfo 0'or`user`='%s" % (USR, U_SECRET)
        rr = self.build_response([('control', '_', exploit)])
        self.cc.request(rr)
        self.assertTrue(SECRET in rr.response_body)

    def testSQLDataTypeMismatch(self):
        exploit = "%s\n50\ninfo user'limit'1,1" % (USR)
        rr = self.build_response([('control', '_', exploit)])
        self.cc.request(rr)
        self.assertTrue('datatype mismatch' in rr.response_body)

    def testSQLOperationalError(self):
        exploit = "%s\n50\ninfo user'" % (USR)
        rr = self.build_response([('control', '_', exploit)])
        self.cc.request(rr)
        self.assertTrue('unrecognized token' in rr.response_body)

    def testSQLWarning(self):
        exploit = "%s\n50\ninfo user';" % (USR)
        rr = self.build_response([('control', '_', exploit)])
        self.cc.request(rr)
        self.assertTrue('execute one statement at a time.' in rr.response_body)

    def testBadRequest(self):
        http = httplib.HTTPConnection(ADDR, PORT)
        http.request('/', 'GET')
        self.assertEqual(501, http.getresponse().status)

    def testBadRequest(self):
        http = httplib.HTTPConnection(ADDR, PORT)
        http.connect()
        http.sock.send('blah\n')
        self.assertTrue('400 = Bad request syntax' in http.sock.recv(1024))

    def testEarlyTermination(self):
        http = httplib.HTTPConnection(ADDR, PORT)
        http.request('GET', '/')

    def testValidCookie(self):
        msg = 'Bryce is awesome'
        rr = crawle.RequestResponse(URL, redirects=None,
                                    headers={'Cookie':'msg="%s";' % msg})
        self.cc.request(rr)
        self.assertTrue(msg in rr.response_body)

    def testExtraCookieMsg(self):
        rr = crawle.RequestResponse(URL, redirects=None,
                                    headers={'Cookie':'msg=a;ms=b'})
        self.cc.request(rr)
        self.assertTrue(S['cookie_msg'] in rr.response_body)

    def testWrongCookieMsg(self):
        rr = crawle.RequestResponse(URL, redirects=None,
                                    headers={'Cookie':'ms=b'})
        self.cc.request(rr)
        self.assertTrue(S['cookie_msg'] in rr.response_body)

    def testInvalidCookie(self):
        rr = crawle.RequestResponse(URL, redirects=None,
                                    headers={'Cookie':':a='})
        self.cc.request(rr)
        self.assertTrue(S['cookie_invalid'] in rr.response_body)


if __name__ == '__main__':
    unittest.main()
