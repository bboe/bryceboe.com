#!/usr/bin/env python
import random, re, socket, sys, time, urllib, HTMLParser
import Pyro.core, Pyro.protocol

URLS = ['http://10.%d.0.2' % x for x in range(1,57)]
URL_REQUEST_TIMEOUT = 1
MAX_PAGE_SIZE = 10*1024
REQUEST_DELAY = 60

KEYWORD_RE = re.compile('\w+')

BASE_BONUS_SCORE = .008
DENSITY_MIN = .01
DENSITY_MAX = .03

TITLE_MULTIPLIER = 2.0
H1_MULTIPLIER = 1.8

INDEX_RMI = 'PYROLOC://localhost:7766/index_server'

def exit_error(msg):
    sys.stderr.write('%s\n' % msg)
    sys.exit(1)

class SimpleHTMLParser(HTMLParser.HTMLParser):
    ROOT = 0; HTML = 1; HEAD = 2; BODY = 3; READING = 4

    def __init__(self):
        HTMLParser.HTMLParser.__init__(self)
        self.state = self.ROOT
        self.title = ''
        self.h1 = []
        self.p = ''
        self.temp = ''
    
    def handle_starttag(self, tag, attrs):
        if self.state == self.ROOT and tag == 'html':
            self.state = self.HTML
        elif self.state == self.HTML and tag == 'head':
            self.state = self.HEAD
        elif self.state == self.HTML and tag == 'body':
            self.state = self.BODY
        elif self.state == self.HEAD and tag == 'title':
            self.state = self.READING
        elif self.state == self.BODY and tag in ('h1', 'p'):
            self.state = self.READING

    def handle_endtag(self, tag):
        if self.state == self.HTML and tag == 'html':
            self.state = self.ROOT
        elif self.state == self.HEAD and tag == 'head':
            self.state = self.HTML
        elif self.state == self.BODY and tag == 'body':
            self.state = self.HTML
        elif self.state == self.READING and tag == 'title':
            self.title = self.temp
            self.temp = ''
            self.state = self.HEAD
        elif self.state == self.READING and tag == 'h1':
            self.h1.append(self.temp)
            self.temp = ''
            self.state = self.BODY
        elif self.state == self.READING and tag == 'p':
            self.p += '%s ' % self.temp
            self.temp = ''
            self.state = self.BODY

    def handle_data(self, data):
        if self.state == self.READING:
            self.temp += data


class ParserScorer(object):
    def __init__(self, skip_check=False):
        self.index_rmi = Pyro.core.getProxyForURI(INDEX_RMI)
        if not skip_check:
            try: # verify connection to index rmi server
                socket.setdefaulttimeout(1)
                self.index_rmi.update_scores('', '', {})
                socket.setdefaulttimeout(None)
            except Pyro.protocol.ProtocolError, e:
                exit_error('Connection test to Index Server failed: %s' %
                           e.args[0])

    def process_page(self, url, page, return_parser=False,
                     return_scores=False):
        parser = SimpleHTMLParser()
        try:
            parser.feed(page)
            parser.close()
        except:
            print 'Couldn\'t parse: %s' % url
            return
        if return_parser:
            return parser
        scores = self.get_base_scores(parser.title, parser.h1, parser.p)
        self.update_bonus_scores(scores, parser.title, parser.h1)
        if return_scores:
            return scores
        self.submit_scores(url, parser.title, scores)

    @staticmethod
    def compute_bonuses(multiplier, n):
        vals = [(1-x/(n+1.))/(.5*n) for x in range(n)]
        return [multiplier * x / sum(vals) for x in vals]

    @staticmethod
    def bonus_scores(multiplier, words):
        position_bonuses = ParserScorer.compute_bonuses(multiplier, len(words))
        bonuses = {}
        for i, word in enumerate(words):
            if word in bonuses: # if word appears > 1 time                      
                bonuses[word] += position_bonuses[i]
            else:
                bonuses[word] = position_bonuses[i]
        return bonuses

    @staticmethod
    def update_bonus_scores(scores, title, h1_list):
        """Updates the base scores by giving bonus points for headlines"""
        bonuses = ParserScorer.bonus_scores(
            TITLE_MULTIPLIER, [x.lower() for x in KEYWORD_RE.findall(title)])
        h1_multipliers = ParserScorer.compute_bonuses(H1_MULTIPLIER,
                                                      len(h1_list))
        for i, h1 in enumerate(h1_list):
            temp = ParserScorer.bonus_scores(
                h1_multipliers[i], [x.lower() for x in KEYWORD_RE.findall(h1)])
            for word in temp:
                if word in bonuses:
                    bonuses[word] += temp[word]
                else:
                    bonuses[word] = temp[word]

        for word, bonus in bonuses.items():
            if word in scores:
                scores[word] *= 1 + bonus
            else:
                scores[word] = BASE_BONUS_SCORE * (1 + bonus)

    def get_base_scores(self, title, h1_list, text):
        """Super simple score function based on word density and thresholds."""
        headers =  ' '.join(h1_list)
        words = [x.lower() for x in KEYWORD_RE.findall(' '.join(
                    [title, headers, text]))]
        keywords = {}
        for word in words:
            if word in keywords:
                keywords[word] += 1
            else:
                keywords[word] = 1
        for word in keywords.keys():
            density = keywords[word] * 1. / len(words)
            if DENSITY_MIN <= density <= DENSITY_MAX:
                keywords[word] = density
            else:
                del keywords[word]
        return keywords

    def submit_scores(self, url, title, scores):
        """Submit scores to index server for a single url.

        url:   url of page with keywords
        scores: a dictionary of keywords to scores for those keywords
                eg: {'apple':.67448, 'banana':.8833}
        """
        while True:
            try:
                self.index_rmi.update_scores(url, title, scores)
                break
            except Pyro.protocol.ProtocolError:
                print 'Connection lost to index server -- restablishing'
                time.sleep(10)
                self.index_rmi = Pyro.core.getProxyForURI(INDEX_RMI)


def start_crawler(debug=False):
    global URLS
    parser_scorer = ParserScorer()
    iteration = 0
    while True:
        iteration += 1
        print 'Iteration: %d' % iteration
        start = time.time()
        random.shuffle(URLS)
        for url in URLS:
            try:
                tt = time.time()
                socket.setdefaulttimeout(URL_REQUEST_TIMEOUT)
                result = urllib.urlopen(url)
                status = result.getcode()
                te = time.time() - tt
                body = result.read()
                if len(body) > MAX_PAGE_SIZE:
                    status = 888
                else:
                    parser_scorer.process_page(url, body)
            except IOError: # tcp connection failed for whatever reason
                status = 999
                te = time.time() - tt
            finally:
                socket.setdefaulttimeout(None)
            print '\t%3d %4.0fms %s' % (status, te * 1000, url)
        sleep_time = REQUEST_DELAY - (time.time() - start)
        if sleep_time > 0:
            time.sleep(sleep_time)

if __name__ == '__main__':
    sys.exit(start_crawler())
