#!/usr/bin/env python

import cgi, getopt, logging, os, re, socket, sys, urlparse
import BaseHTTPServer, SocketServer
import Pyro.core, Pyro.protocol

INDEX_RMI = 'PYROLOC://localhost:7766/index_server'
SERVER_PORT = 10000

class ThreadingHTTPServer(SocketServer.ThreadingMixIn,
                          BaseHTTPServer.HTTPServer): pass

class SearchHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    allowed_re = re.compile('\w+')
    home_path = "/"
    search_path = "/search"
    style_path = "/search.css"
    icon_path = "/favicon.ico"
    header = """
<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>%s</title>
    <link href="/search.css" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <div id="content">
      <div id="banner">
        <h1>%s</h1>
      </div>

      <div id="main">
"""
    footer = """
      </div>
      <div id="footer">
        <hr />
        <p>The <a href="/">Goollible</a> search engine indexes more pages than
           any other search engine.</p>
      </div>
    </div>
  </body>
</html>
"""

    def style(self, params):
        self.send_response(200)
        self.send_header('Content-type', 'text/css')
        self.end_headers()
        self.wfile.write("""
body {
  font-family: Arial, Helvetica, sans-serif;
  font-size: 10pt;
  background: white;
  color: black;
}

#content {
  border: 2px solid black;
  width: 800px;
  margin-top: 2em;
  margin-left: auto;
  margin-right:auto;
}

#banner {
  padding: 1em 1em 1em 1em;
  border: 0px solid red;
  text-align: center;
}

#main {
  padding: 1em 2em 2em 1em;
  border: 0px solid blue;
  min-height: 300px;
}

#footer {
  border: 0px solid yellow;
  font-size: 8pt;
  padding: 1em 1em 1em 1em;
  text-align: center;
}

#footer a {
  color: black;
}

#search_form {
  border: 0px solid yellow;
  text-align: center;
  padding: 4em 1em 1em 1em;
}

li {
  margin: .5em 0em .5em 0em;
}
""")
        return

    def icon(self, params):
        self.send_response(200)
        self.send_header('Content-type', 'image/vnd.microsoft.icon')
        self.end_headers()
        try:
            f = open("favicon.ico", "r")
            self.wfile.write(f.read())
        except Exception, err: pass

    def home(self, params):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(self.header % ("Goollible", "Goollible"))
        self.wfile.write("""
<div id="search_form">
<form action="%s" method="post">
  <p>Search term: <input type="text" name="term" /></p>
  <p><input type="submit" name="search" value="Goollible Search"><input type="submit" name="goollible" value="I'm Feeling Goollible"></p>
</form>
</div>
""" % self.search_path)
        self.wfile.write(self.footer)
        return

    def search(self, terms):
        if len(terms) > 0:
            try:
                results = self.index_rmi.search(terms)
            except Pyro.protocol.ProtocolError:
                SearchHandler.index_rmi = Pyro.core.getProxyForURI(INDEX_RMI)
                self.send_error(500, 'Connection lost to index server')
                return
            body = '\n<ol>\n'
            for result in results:
                body += ''.join(['  <li><a href="%s"><span class="result_tit',
                                 'le">%s</span></a></li>\n']) % (result[0],
                                                                 result[2])
            body += '</ol>\n'
        else:
            term = ''
            body = 'There are no search terms'
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(self.header % ('Spider','Search results for "%s" '
                                        % ' '.join(terms)))
        self.wfile.write(body)
        self.wfile.write(self.footer)

    def do_GET(self):
        try:
            self.logger.debug("Received GET request with path: %s" %
                              self.path)
            req = urlparse.urlparse(self.path)
            self.logger.debug("Received request resource: %s" % req.path)
            params = urlparse.parse_qs(req.query)
            self.logger.debug("Received params: %s" % str(params))

            if req.path == self.home_path:
                self.home(params)
            elif req.path == self.style_path:
                self.style(params)
            elif req.path == self.icon_path:
                self.icon(params)
            else:
                self.send_error(404,'File Not Found: %s' % self.path)
        except Exception, err:
            self.wfile.write("An error occurred: " + str(err))
            self.logger.error("An error occurred: " + str(err))

    def do_POST(self):
        self.logger.debug("Received POST request with path: %s" % self.path)
        if self.path != self.search_path:
            self.send_error(400, 'Unknown resource: %s' % self.path)
            return
        try:
            form = cgi.FieldStorage(fp=self.rfile, headers=self.headers,
                                    environ={
                    'REQUEST_METHOD':'POST',
                    'CONTENT_TYPE':self.headers['Content-Type']})
            self.logger.debug("Received parameters: %s" % str(form))
            terms = self.allowed_re.findall(form.getfirst('term'))
        except TypeError:
            terms = []
        self.search(terms)

def usage(fname):
    sys.stderr.write('%s [-d (debug)] [-p <port>]\n' % fname)

def exit_error(msg):
    sys.stderr.write('%s\n' % msg)
    sys.exit(1)

def start_server():
    debug = False
    loglevel = logging.INFO
    script_name = os.path.basename(sys.argv[0])

    try:
        opts, args = getopt.getopt(sys.argv[1:], "dihs:p:b:")
    except getopt.error, msg:
        usage(script_name)
        return 1
    for option, args in opts:
        if option == "-d":
            debug = True
            loglevel = logging.DEBUG
        if option == "-h":
            usage(script_name)
            return 1
        if option == "-p":
            global SERVER_PORT
            SERVER_PORT = int(args)

    logging.basicConfig(level=loglevel)
    logger = logging.getLogger('Spider')
    SearchHandler.logger = logger

    SearchHandler.index_rmi = Pyro.core.getProxyForURI(INDEX_RMI)
    try: # verify connection to index rmi server
        socket.setdefaulttimeout(1)
        SearchHandler.index_rmi.update_scores('', '', {})
        socket.setdefaulttimeout(None)
    except Pyro.protocol.ProtocolError, e:
        exit_error('Connection test to Index Server failed: %s' %
                   e.args[0])
    try:
        logger.info("Starting Search Server on port %d..." % SERVER_PORT)
        httpd = ThreadingHTTPServer(('', SERVER_PORT), SearchHandler)
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info('Shutting down Search Server...')
        httpd.socket.close()

if __name__ == '__main__':
    sys.exit(start_server())
