#!/usr/bin/env python

import index_server, crawler
import unittest

class TestIndexServer(unittest.TestCase):
    def setUp(self):
        self.server = index_server.IndexServer()

    def test_empty_results(self):
        self.assertEqual(self.server.search(['apple']), [])

    def test_remove_replace_result(self):
        # test single insert
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])

        # test remove and replace
        self.server.update_scores('127.0.0.1', '1', {'banana':.05})
        self.assertEqual(self.server.search(['banana']),
                         [('127.0.0.1', .05, '1')])
        self.assertEqual(self.server.search(['apple']), [])

    def test_set_and_remove(self):
        self.server.update_scores('127.0.0.1', '1',
                                  {'apple':.04, 'banana':.05})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])
        self.assertEqual(self.server.search(['banana']),
                         [('127.0.0.1', .05, '1')])
        self.server.update_scores('127.0.0.1', '1', {})
        self.assertEqual(self.server.search(['apple']), [])

    def test_update_and_add(self):
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])
        self.server.update_scores('127.0.0.1', '1', {'apple':.9, 'banana':.05})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .9, '1')])
        self.assertEqual(self.server.search(['banana']),
                         [('127.0.0.1', .05, '1')])

    def test_simple_two_hosts(self):
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])
        self.server.update_scores('127.0.0.2', '2', {'apple':.9})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.2', .9, '2'), ('127.0.0.1', .04, '1')])

    def test_two_host_same_score(self):
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])
        self.server.update_scores('127.0.0.2', '2', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.2', .04, '2'), ('127.0.0.1', .04, '1')])

    def test_two_host_diff_words(self):
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.assertEqual(self.server.search(['apple']),
                         [('127.0.0.1', .04, '1')])
        self.server.update_scores('127.0.0.2', '2', {'banana':.04})
        self.assertEqual(self.server.search(['banana']),
                         [('127.0.0.2', .04, '2')])

    def test_two_keywords_no_results(self):
        self.assertEqual(self.server.search(['apple', 'banana']), [])

    def test_two_host_diff_words_two_keywords(self):
        self.server.update_scores('127.0.0.1', '1', {'apple':.04})
        self.server.update_scores('127.0.0.2', '2', {'banana':.04})
        self.assertEqual(self.server.search(['apple', 'banana']),
                         [('127.0.0.2', .04, '2'), ('127.0.0.1', .04, '1')])

    def test_one_host_diff_words_two_keywords(self):
        self.server.update_scores('127.0.0.1', '1',
                                  {'apple':.02, 'banana':.03})
        self.assertEqual(self.server.search(['apple', 'banana']),
                         [('127.0.0.1', .05, '1')])

    def test_two_hosts_diff_words_two_keywords(self):
        self.server.update_scores('127.0.0.1', '1',
                                  {'apple':.02, 'banana':.03})
        self.server.update_scores('127.0.0.2', '2',
                                  {'apple':.01, 'banana':.02})
        self.assertEqual(self.server.search(['apple', 'banana']),
                         [('127.0.0.1', .05, '1'), ('127.0.0.2', .03, '2')])

    def test_two_hosts_diff_words_two_keywords_part2(self):
        self.server.update_scores('127.0.0.1', '1',
                                  {'apple':.02, 'banana':.03})
        self.server.update_scores('127.0.0.2', '2',
                                  {'banana':.02})
        self.assertEqual(self.server.search(['apple', 'banana']),
                         [('127.0.0.1', .05, '1'), ('127.0.0.2', .02, '2')])
        self.assertEqual(self.server.search(['apple', 'banana']),
                         [('127.0.0.1', .05, '1'), ('127.0.0.2', .02, '2')])

class TestParserScorer(unittest.TestCase):
    def setUp(self):
        self.ps = crawler.ParserScorer(skip_check=True)
        
    def test_parse_html(self):
        parser = self.ps.process_page('', """
1
<html>
  2
  <head>
    3
    <title>This is the title of my super awesome web page</title>
    <title><a name="blah"/>This is the <b>other</b> title!</title>
    <h1>Nope</h1>
    <p>This makes no sense here</p>
    4
  </head>
  5
  <title>This title should be ignored</title>
  <body>
    6
    <title>This title should also be ignored</title>
    <h1>Heading</h1>
    <p>One Paragraph!</p>
    <h1>More Heading!</h1>
    <p>paragraph w/ <em>em</em> text</p>
    7
  </body>
  8
</html>
9
""", return_parser=True)
        self.assertEqual(parser.title, 'This is the other title!')
        self.assertEqual(parser.h1, ['Heading', 'More Heading!'])
        self.assertEqual(parser.p, 'One Paragraph! paragraph w/ em text ')

    def test_score_html(self):
        body1 = ' '.join([str(x) for x in range(33)])
        body2 = ' '.join([str(x) for x in range(66)]) + ' 0'
        body3 = ' '.join([str(x) for x in range(100)])
        scores = self.ps.process_page('127.0.0.1', """<html><body><p>%s</p>
</body></html>""" % body1, return_scores=True)
        self.assertEqual(scores, {})
        body1 += ' 34'
        scores = self.ps.process_page('127.0.0.1', """<html><body><p>%s</p>
</body></html>""" % body1, return_scores=True)
        for score in scores.values():
            self.assertEqual(score, 1./34)
        scores = self.ps.process_page('127.0.0.1', """<html><body><p>%s</p>
</body></html>""" % body2, return_scores=True)
        self.assertEqual(scores['0'], 2./67)
        scores = self.ps.process_page('127.0.0.1', """<html><body><p>%s</p>
</body></html>""" % body3, return_scores=True)
        self.assertEqual(len(scores), 100)
        body3 += ' 100'
        scores = self.ps.process_page('127.0.0.1', """<html><body><p>%s</p>
</body></html>""" % body3, return_scores=True)
        self.assertEqual(scores, {})


if __name__ == '__main__':
    unittest.main()
