#!/usr/bin/env python
import Pyro.core, Pyro.protocol
import sys

def display_by_word(results):
    t = {}
    for kw, urls in results.items():
        t[kw] = sorted(urls.items(), key=lambda x: x[1], reverse=True)[0][1]

    kw_by_score = sorted(t.items(), key=lambda x: x[1], reverse=True)
    for i, (kw, _) in enumerate(kw_by_score):
        print '%3d. %s' % (i, kw)
        st = sorted(results[kw].items(), key=lambda x: x[1], reverse=True)
        for j, (url, (score, _)) in enumerate(st):
            print '\t%3d. %.3f %s' % (j, score, url)

def display_unique_pages(results):
    unique = set()
    for x in results.values():
        for url in x.keys():
            unique.add(url)

    unique = sorted(list(unique))

    for url in unique:
        print url

if __name__ == '__main__':
    rmi = Pyro.core.getProxyForURI('PYROLOC://localhost:7766/index_server')
    results = rmi.get_scores()

    if len(sys.argv) > 1 :
        display_unique_pages(results)
        sys.exit(1)
    
    display_by_word(results)
