#!/usr/bin/env python

import cPickle, os, sys, time
import Pyro.core

def exit_error(msg):
    sys.stderr.write('%s\n' % msg)
    sys.exit(1)

class IndexServer(Pyro.core.ObjBase):
    def __init__(self, recover_file=None):
        if recover_file == None:
            self.scores = {}
            self.titles = {}
        else:
            if not os.path.isfile(recover_file):
               exit_error(''.join(['Cannot recover from %s as it does not ',
                                   'exist or is not a file']) % recover_file)
            try:
                self.scores, self.titles = cPickle.load(open(recover_file))
                print 'Recovered %d keyword(s)' % len(self.scores)
            except cPickle.UnpicklingError:
                exit_error('%s is not a valid pickle file' % recover_file)
            
        Pyro.core.ObjBase.__init__(self)

    def get_scores(self):
        return self.scores

    def update_scores(self, url, title, scores, debug=False):
        current_kwds = sorted(self.scores.keys())
        insert_kwds = sorted(scores.keys())
        cur_idx = ins_idx = 0

        self.titles[url] = title

        while cur_idx < len(current_kwds) or ins_idx < len(insert_kwds):
            current_kwd = insert_kwd = None
            if cur_idx < len(current_kwds):
                current_kwd = current_kwds[cur_idx]
            if ins_idx < len(insert_kwds):
                insert_kwd = insert_kwds[ins_idx]

            if current_kwd and insert_kwd and current_kwd == insert_kwd:
                if debug: print 'update'
                self.scores[insert_kwd][url] = (scores[insert_kwd],
                                                 time.time())
                cur_idx += 1
                ins_idx += 1
            elif not insert_kwd or current_kwd and current_kwd < insert_kwd:
                if debug: print 'remove'
                if url in self.scores[current_kwd]:
                    del self.scores[current_kwd][url]
                if len(self.scores[current_kwd]) == 0:
                    del self.scores[current_kwd]
                cur_idx += 1
            else:
                if debug: print 'insert'
                self.scores[insert_kwd] = {url:(scores[insert_kwd],
                                                time.time())}
                ins_idx += 1

    def search(self, keywords):
        final_scores = None
        for keyword in keywords:
            if keyword not in self.scores:
                continue
            if final_scores == None:
                final_scores = dict(self.scores[keyword])
            else:
                for url in self.scores[keyword].keys():
                    if url in final_scores:
                        final_score, final_date = final_scores[url]
                        temp_score, temp_date = self.scores[keyword][url]
                        final_scores[url] = (final_score + temp_score,
                                             max(final_date, temp_date))
                    else:
                        final_scores[url] = self.scores[keyword][url]
        if final_scores == None:
            return []
        urls = sorted(final_scores.items(), key=lambda x: x[1], reverse=True)
        return [(x[0], x[1][0], self.titles[x[0]]) for x in urls]

    def save_scores(self):
        if len(self.scores) > 0:
            out_name = 'recover_%s.pkl' % time.strftime('%d%H%M%S')
            out = open(out_name, 'w')
            cPickle.dump((self.scores, self.titles), out,
                         cPickle.HIGHEST_PROTOCOL)
            out.close()
            print 'Saved results to %s' % out_name

def start_index_server():
    def usage():
        sys.stderr.write('Usage: %s [recover_file]\n' %
                         os.path.basename(sys.argv[0]))
        sys.exit(1)

    if len(sys.argv) > 2:
        usage()
    elif len(sys.argv) == 2:
        recover_file = sys.argv[1]
    else:
        recover_file = None
    

    Pyro.core.initServer()
    daemon = Pyro.core.Daemon(host='localhost')
    index_server = IndexServer(recover_file=recover_file)
    uri = daemon.connect(index_server, 'index_server')
    print 'PYROLOC://%s:%d/index_server' % (daemon.hostname, daemon.port)

    try:
        daemon.requestLoop()
    except (KeyboardInterrupt, SystemExit):
        index_server.save_scores()
    except:
        index_server.save_scores()
        raise
    return 0

if __name__ == '__main__':
    sys.exit(start_index_server())
