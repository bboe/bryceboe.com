2010/05/13 -- Bryce Boe
  * Modified to download all photos from an album a user is tagged in